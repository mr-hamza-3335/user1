export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          role: 'admin' | 'hr' | 'company';
          created_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          role: 'admin' | 'hr' | 'company';
          created_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          role?: 'admin' | 'hr' | 'company';
          created_at?: string;
        };
      };
      companies: {
        Row: {
          id: string;
          user_id: string;
          company_name: string;
          industry_type: string;
          contact_person: string;
          phone: string;
          address: string | null;
          area: string;
          registration_number: string | null;
          status: 'pending' | 'approved' | 'rejected';
          rejection_reason: string | null;
          approved_by: string | null;
          approved_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          company_name: string;
          industry_type: string;
          contact_person: string;
          phone: string;
          address?: string | null;
          area?: string;
          registration_number?: string | null;
          status?: 'pending' | 'approved' | 'rejected';
          rejection_reason?: string | null;
          approved_by?: string | null;
          approved_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          company_name?: string;
          industry_type?: string;
          contact_person?: string;
          phone?: string;
          address?: string | null;
          area?: string;
          registration_number?: string | null;
          status?: 'pending' | 'approved' | 'rejected';
          rejection_reason?: string | null;
          approved_by?: string | null;
          approved_at?: string | null;
          created_at?: string;
        };
      };
      candidates: {
        Row: {
          id: string;
          full_name: string;
          father_name: string | null;
          cnic: string | null;
          phone: string | null;
          email: string | null;
          address: string | null;
          area: string | null;
          city: string;
          date_of_birth: string | null;
          gender: 'male' | 'female' | 'other' | null;
          education: string | null;
          education_detail: string | null;
          experience_years: number;
          experience_detail: string | null;
          role_category: string;
          skills: string[];
          languages: string[];
          availability: 'available' | 'hired' | 'notice_period';
          current_salary: number | null;
          expected_salary: number | null;
          notes: string | null;
          added_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          full_name: string;
          father_name?: string | null;
          cnic?: string | null;
          phone?: string | null;
          email?: string | null;
          address?: string | null;
          area?: string | null;
          city?: string;
          date_of_birth?: string | null;
          gender?: 'male' | 'female' | 'other' | null;
          education?: string | null;
          education_detail?: string | null;
          experience_years?: number;
          experience_detail?: string | null;
          role_category: string;
          skills?: string[];
          languages?: string[];
          availability?: 'available' | 'hired' | 'notice_period';
          current_salary?: number | null;
          expected_salary?: number | null;
          notes?: string | null;
          added_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          father_name?: string | null;
          cnic?: string | null;
          phone?: string | null;
          email?: string | null;
          address?: string | null;
          area?: string | null;
          city?: string;
          date_of_birth?: string | null;
          gender?: 'male' | 'female' | 'other' | null;
          education?: string | null;
          education_detail?: string | null;
          experience_years?: number;
          experience_detail?: string | null;
          role_category?: string;
          skills?: string[];
          languages?: string[];
          availability?: 'available' | 'hired' | 'notice_period';
          current_salary?: number | null;
          expected_salary?: number | null;
          notes?: string | null;
          added_by?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      candidate_cvs: {
        Row: {
          id: string;
          candidate_id: string;
          file_url: string;
          file_name: string;
          file_size: number | null;
          uploaded_by: string;
          uploaded_at: string;
        };
        Insert: {
          id?: string;
          candidate_id: string;
          file_url: string;
          file_name: string;
          file_size?: number | null;
          uploaded_by: string;
          uploaded_at?: string;
        };
        Update: {
          id?: string;
          candidate_id?: string;
          file_url?: string;
          file_name?: string;
          file_size?: number | null;
          uploaded_by?: string;
          uploaded_at?: string;
        };
      };
      shortlists: {
        Row: {
          id: string;
          company_id: string;
          candidate_id: string;
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          company_id: string;
          candidate_id: string;
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          company_id?: string;
          candidate_id?: string;
          notes?: string | null;
          created_at?: string;
        };
      };
      interview_requests: {
        Row: {
          id: string;
          company_id: string;
          candidate_id: string;
          proposed_date: string | null;
          proposed_time: string | null;
          interview_type: 'in_person' | 'phone' | 'video' | null;
          location: string | null;
          message: string | null;
          status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
          admin_notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          company_id: string;
          candidate_id: string;
          proposed_date?: string | null;
          proposed_time?: string | null;
          interview_type?: 'in_person' | 'phone' | 'video' | null;
          location?: string | null;
          message?: string | null;
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled';
          admin_notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          company_id?: string;
          candidate_id?: string;
          proposed_date?: string | null;
          proposed_time?: string | null;
          interview_type?: 'in_person' | 'phone' | 'video' | null;
          location?: string | null;
          message?: string | null;
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled';
          admin_notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      hiring_records: {
        Row: {
          id: string;
          company_id: string;
          candidate_id: string;
          interview_id: string | null;
          position_title: string | null;
          hired_date: string | null;
          salary_offered: number | null;
          status: 'hired' | 'rejected' | 'offer_pending';
          notes: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          company_id: string;
          candidate_id: string;
          interview_id?: string | null;
          position_title?: string | null;
          hired_date?: string | null;
          salary_offered?: number | null;
          status: 'hired' | 'rejected' | 'offer_pending';
          notes?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          company_id?: string;
          candidate_id?: string;
          interview_id?: string | null;
          position_title?: string | null;
          hired_date?: string | null;
          salary_offered?: number | null;
          status?: 'hired' | 'rejected' | 'offer_pending';
          notes?: string | null;
          created_at?: string;
        };
      };
      activity_logs: {
        Row: {
          id: string;
          user_id: string;
          action: string;
          entity_type: string | null;
          entity_id: string | null;
          details: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          action: string;
          entity_type?: string | null;
          entity_id?: string | null;
          details?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          action?: string;
          entity_type?: string | null;
          entity_id?: string | null;
          details?: Json | null;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}
