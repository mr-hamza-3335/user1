export type UserRole = 'admin' | 'hr' | 'company';

export type CompanyStatus = 'pending' | 'approved' | 'rejected';

export type AvailabilityStatus = 'available' | 'hired' | 'notice_period';

export type InterviewType = 'in_person' | 'phone' | 'video';

export type InterviewStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export type HiringStatus = 'hired' | 'rejected' | 'offer_pending';

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
  created_at: string;
}

export interface Company {
  id: string;
  user_id: string;
  company_name: string;
  industry_type: string;
  contact_person: string;
  phone: string;
  address: string | null;
  area: string;
  registration_number: string | null;
  status: CompanyStatus;
  rejection_reason: string | null;
  approved_by: string | null;
  approved_at: string | null;
  created_at: string;
  profiles?: Profile;
}

export interface Candidate {
  id: string;
  full_name: string;
  father_name: string | null;
  cnic: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  area: string | null;
  city: string;
  date_of_birth: string | null;
  gender: 'male' | 'female' | 'other' | null;
  education: string | null;
  education_detail: string | null;
  experience_years: number;
  experience_detail: string | null;
  role_category: string;
  skills: string[];
  languages: string[];
  availability: AvailabilityStatus;
  current_salary: number | null;
  expected_salary: number | null;
  notes: string | null;
  added_by: string;
  created_at: string;
  updated_at: string;
  profiles?: Profile;
  candidate_cvs?: CandidateCV[];
}

export interface CandidateCV {
  id: string;
  candidate_id: string;
  file_url: string;
  file_name: string;
  file_size: number | null;
  uploaded_by: string;
  uploaded_at: string;
}

export interface Shortlist {
  id: string;
  company_id: string;
  candidate_id: string;
  notes: string | null;
  created_at: string;
  candidates?: Candidate;
}

export interface InterviewRequest {
  id: string;
  company_id: string;
  candidate_id: string;
  proposed_date: string | null;
  proposed_time: string | null;
  interview_type: InterviewType | null;
  location: string | null;
  message: string | null;
  status: InterviewStatus;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
  candidates?: Candidate;
  companies?: Company;
}

export interface HiringRecord {
  id: string;
  company_id: string;
  candidate_id: string;
  interview_id: string | null;
  position_title: string | null;
  hired_date: string | null;
  salary_offered: number | null;
  status: HiringStatus;
  notes: string | null;
  created_at: string;
  candidates?: Candidate;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
  profiles?: Profile;
}

export interface DashboardStats {
  totalCandidates: number;
  totalCompanies: number;
  pendingApprovals: number;
  hiresThisMonth: number;
  interviewRequests: number;
  myCandidates?: number;
  cvsThisWeek?: number;
  myShortlist?: number;
  myInterviews?: number;
  myHires?: number;
  availableCandidates?: number;
}
