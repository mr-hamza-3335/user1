import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value,
            ...options,
          });
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.set({
            name,
            value,
            ...options,
          });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value: '',
            ...options,
          });
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.set({
            name,
            value: '',
            ...options,
          });
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;

  // Public routes
  if (path === '/login' || path === '/register') {
    if (user) {
      // Redirect logged-in users to their dashboard
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();

      if (profile?.role === 'admin') {
        return NextResponse.redirect(new URL('/admin/dashboard', request.url));
      } else if (profile?.role === 'hr') {
        return NextResponse.redirect(new URL('/hr/dashboard', request.url));
      } else if (profile?.role === 'company') {
        return NextResponse.redirect(new URL('/company/dashboard', request.url));
      }
    }
    return response;
  }

  // Protected routes - require authentication
  if (!user) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  // Get user profile for role checking
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  const userRole = profile?.role;

  // Admin routes - only admin allowed
  if (path.startsWith('/admin')) {
    if (userRole !== 'admin') {
      return NextResponse.redirect(new URL('/login', request.url));
    }
    return response;
  }

  // HR routes - admin or HR allowed
  if (path.startsWith('/hr')) {
    if (userRole !== 'admin' && userRole !== 'hr') {
      return NextResponse.redirect(new URL('/login', request.url));
    }
    return response;
  }

  // Company routes - only approved companies allowed
  if (path.startsWith('/company')) {
    if (userRole !== 'company') {
      return NextResponse.redirect(new URL('/login', request.url));
    }

    // Check if company is approved
    const { data: company } = await supabase
      .from('companies')
      .select('status')
      .eq('user_id', user.id)
      .single();

    if (company?.status !== 'approved') {
      return NextResponse.redirect(new URL('/login?status=pending', request.url));
    }

    return response;
  }

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
