'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Search,
  Star,
  Calendar,
  CheckCircle,
  LogOut,
  Briefcase,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

const navItems = [
  { href: '/company/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/company/search', label: 'Search Candidates', icon: Search },
  { href: '/company/shortlist', label: 'My Shortlist', icon: Star },
  { href: '/company/interviews', label: 'Interviews', icon: Calendar },
  { href: '/company/hired', label: 'Hired', icon: CheckCircle },
];

export default function CompanySidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/login');
  };

  return (
    <aside className="fixed left-0 top-0 h-full w-60 bg-[#1C2533] text-white z-50">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-full bg-[#e87e0d] flex items-center justify-center">
            <Briefcase className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
              BALDIA
            </h1>
            <h1 className="text-lg font-bold leading-tight text-[#e87e0d]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
              ROZGAR
            </h1>
          </div>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 rounded-md transition-colors',
                  isActive
                    ? 'bg-[#e87e0d]/20 text-[#e87e0d] border-l-4 border-[#e87e0d]'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-4">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 w-full text-gray-300 hover:text-white hover:bg-white/5 rounded-md transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm font-medium">Logout</span>
        </button>
      </div>
    </aside>
  );
}
