'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Loader2, Plus, X } from 'lucide-react';
import Link from 'next/link';

const educationLevels = [
  'No Formal Education',
  'Primary',
  'Middle',
  'Matric',
  'Intermediate',
  'Diploma',
  'Bachelor',
  'Master',
  'Other',
];

const roleCategories = [
  'Production',
  'Quality Control',
  'Maintenance',
  'Warehouse',
  'Administration',
  'Sales',
  'Accounting',
  'Security',
  'Driver',
  'Helper',
  'Supervisor',
  'Manager',
  'Other',
];

const languagesList = ['Urdu', 'English', 'Sindhi', 'Punjabi', 'Pashto'];

export default function AddCandidate() {
  const router = useRouter();
  const supabase = createClient();
  const [loading, setLoading] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    fatherName: '',
    cnic: '',
    phone: '',
    email: '',
    dateOfBirth: '',
    gender: '',
    address: '',
    area: '',
    education: '',
    educationDetail: '',
    experienceYears: '',
    experienceDetail: '',
    currentSalary: '',
    expectedSalary: '',
    roleCategory: '',
    skills: [] as string[],
    languages: [] as string[],
    availability: 'available',
    notes: '',
  });

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const addSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        skills: [...prev.skills, skillInput.trim()],
      }));
      setSkillInput('');
    }
  };

  const removeSkill = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skill),
    }));
  };

  const toggleLanguage = (language: string) => {
    setFormData((prev) => ({
      ...prev,
      languages: prev.languages.includes(language)
        ? prev.languages.filter((l) => l !== language)
        : [...prev.languages, language],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('candidates')
        .insert({
          full_name: formData.fullName,
          father_name: formData.fatherName || null,
          cnic: formData.cnic || null,
          phone: formData.phone || null,
          email: formData.email || null,
          date_of_birth: formData.dateOfBirth || null,
          gender: formData.gender || null,
          address: formData.address || null,
          area: formData.area || null,
          education: formData.education || null,
          education_detail: formData.educationDetail || null,
          experience_years: parseInt(formData.experienceYears) || 0,
          experience_detail: formData.experienceDetail || null,
          current_salary: formData.currentSalary ? parseInt(formData.currentSalary) : null,
          expected_salary: formData.expectedSalary ? parseInt(formData.expectedSalary) : null,
          role_category: formData.roleCategory,
          skills: formData.skills,
          languages: formData.languages,
          availability: formData.availability,
          notes: formData.notes || null,
          added_by: userData.user.id,
        })
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabase.from('activity_logs').insert({
        action: 'Added new candidate',
        entity_type: 'candidate',
        entity_id: data.id,
      });

      router.push('/admin/candidates');
    } catch (error) {
      console.error('Error adding candidate:', error);
      alert('Error adding candidate. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/candidates">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Add New Candidate
          </h1>
          <p className="text-muted-foreground">Create a new candidate profile</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name *</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => handleChange('fullName', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fatherName">Father Name</Label>
              <Input
                id="fatherName"
                value={formData.fatherName}
                onChange={(e) => handleChange('fatherName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cnic">CNIC</Label>
              <Input
                id="cnic"
                placeholder="XXXXX-XXXXXXX-X"
                value={formData.cnic}
                onChange={(e) => handleChange('cnic', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                placeholder="03XX-XXXXXXX"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formData.dateOfBirth}
                onChange={(e) => handleChange('dateOfBirth', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Gender</Label>
              <Select value={formData.gender} onValueChange={(value) => handleChange('gender', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="area">Area</Label>
              <Input
                id="area"
                placeholder="e.g., Baldia Town"
                value={formData.area}
                onChange={(e) => handleChange('area', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Education */}
        <Card>
          <CardHeader>
            <CardTitle>Education</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="education">Education Level</Label>
              <Select value={formData.education} onValueChange={(value) => handleChange('education', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select education level" />
                </SelectTrigger>
                <SelectContent>
                  {educationLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="educationDetail">Education Details</Label>
              <Textarea
                id="educationDetail"
                placeholder="Institution, major, year completed, etc."
                value={formData.educationDetail}
                onChange={(e) => handleChange('educationDetail', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Experience */}
        <Card>
          <CardHeader>
            <CardTitle>Experience</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="experienceYears">Experience (Years)</Label>
              <Input
                id="experienceYears"
                type="number"
                min="0"
                value={formData.experienceYears}
                onChange={(e) => handleChange('experienceYears', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentSalary">Current Salary (PKR)</Label>
              <Input
                id="currentSalary"
                type="number"
                placeholder="e.g., 25000"
                value={formData.currentSalary}
                onChange={(e) => handleChange('currentSalary', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="expectedSalary">Expected Salary (PKR)</Label>
              <Input
                id="expectedSalary"
                type="number"
                placeholder="e.g., 35000"
                value={formData.expectedSalary}
                onChange={(e) => handleChange('expectedSalary', e.target.value)}
              />
            </div>
            <div className="space-y-2 md:col-span-3">
              <Label htmlFor="experienceDetail">Experience Details</Label>
              <Textarea
                id="experienceDetail"
                placeholder="Previous companies, roles, responsibilities..."
                value={formData.experienceDetail}
                onChange={(e) => handleChange('experienceDetail', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Professional */}
        <Card>
          <CardHeader>
            <CardTitle>Professional Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="roleCategory">Role Category *</Label>
              <Select
                value={formData.roleCategory}
                onValueChange={(value) => handleChange('roleCategory', value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select role category" />
                </SelectTrigger>
                <SelectContent>
                  {roleCategories.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Skills</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a skill and press Enter"
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addSkill();
                    }
                  }}
                />
                <Button type="button" onClick={addSkill} variant="outline">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="ml-1 hover:text-red-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Languages</Label>
              <div className="flex flex-wrap gap-4">
                {languagesList.map((language) => (
                  <div key={language} className="flex items-center space-x-2">
                    <Checkbox
                      id={language}
                      checked={formData.languages.includes(language)}
                      onCheckedChange={() => toggleLanguage(language)}
                    />
                    <Label htmlFor={language} className="text-sm font-normal cursor-pointer">
                      {language}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status */}
        <Card>
          <CardHeader>
            <CardTitle>Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Availability</Label>
              <RadioGroup
                value={formData.availability}
                onValueChange={(value) => handleChange('availability', value)}
                className="flex flex-wrap gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="available" id="available" />
                  <Label htmlFor="available" className="font-normal cursor-pointer">
                    Available
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="hired" id="hired" />
                  <Label htmlFor="hired" className="font-normal cursor-pointer">
                    Hired
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="notice_period" id="notice_period" />
                  <Label htmlFor="notice_period" className="font-normal cursor-pointer">
                    Notice Period
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes about the candidate..."
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Button variant="outline" asChild>
            <Link href="/admin/candidates">Cancel</Link>
          </Button>
          <Button type="submit" className="bg-[#e87e0d] hover:bg-[#d16f0a]" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Candidate'
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
