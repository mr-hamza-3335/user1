'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Building2, Clock, CheckCircle, Calendar, Plus, UserPlus, ClipboardList } from 'lucide-react';
import Link from 'next/link';
import { formatDateTime } from '@/lib/utils';

interface DashboardStats {
  totalCandidates: number;
  totalCompanies: number;
  pendingApprovals: number;
  hiresThisMonth: number;
  interviewRequests: number;
}

interface ActivityLog {
  id: string;
  action: string;
  entity_type: string | null;
  created_at: string;
  profiles: { full_name: string } | null;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalCandidates: 0,
    totalCompanies: 0,
    pendingApprovals: 0,
    hiresThisMonth: 0,
    interviewRequests: 0,
  });
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch candidates count
      const { count: candidatesCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true });

      // Fetch companies count
      const { count: companiesCount } = await supabase
        .from('companies')
        .select('*', { count: 'exact', head: true });

      // Fetch pending approvals
      const { count: pendingCount } = await supabase
        .from('companies')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      // Fetch hires this month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);
      
      const { count: hiresCount } = await supabase
        .from('hiring_records')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', startOfMonth.toISOString());

      // Fetch interview requests
      const { count: interviewsCount } = await supabase
        .from('interview_requests')
        .select('*', { count: 'exact', head: true });

      setStats({
        totalCandidates: candidatesCount || 0,
        totalCompanies: companiesCount || 0,
        pendingApprovals: pendingCount || 0,
        hiresThisMonth: hiresCount || 0,
        interviewRequests: interviewsCount || 0,
      });

      // Fetch recent activities
      const { data: activityData } = await supabase
        .from('activity_logs')
        .select('id, action, entity_type, created_at, profiles(full_name)')
        .order('created_at', { ascending: false })
        .limit(10);

      setActivities(activityData as ActivityLog[] || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { title: 'Total Candidates', value: stats.totalCandidates, icon: Users, color: 'text-blue-600', bgColor: 'bg-blue-100' },
    { title: 'Total Companies', value: stats.totalCompanies, icon: Building2, color: 'text-purple-600', bgColor: 'bg-purple-100' },
    { title: 'Pending Approvals', value: stats.pendingApprovals, icon: Clock, color: 'text-yellow-600', bgColor: 'bg-yellow-100' },
    { title: 'Hires This Month', value: stats.hiresThisMonth, icon: CheckCircle, color: 'text-green-600', bgColor: 'bg-green-100' },
    { title: 'Interview Requests', value: stats.interviewRequests, icon: Calendar, color: 'text-orange-600', bgColor: 'bg-orange-100' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground">Welcome to Baldia Rozgar Admin Panel</p>
        </div>
        <div className="flex gap-3">
          <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
            <Link href="/admin/candidates/add">
              <Plus className="w-4 h-4 mr-2" />
              Add Candidate
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/admin/hr-users">
              <UserPlus className="w-4 h-4 mr-2" />
              Add HR User
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                      {stat.value}
                    </p>
                  </div>
                  <div className={`w-12 h-12 rounded-full ${stat.bgColor} flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="outline" className="border-[#e87e0d] text-[#e87e0d] hover:bg-[#e87e0d]/10">
              <Link href="/admin/companies">
                <ClipboardList className="w-4 h-4 mr-2" />
                Review Companies
                {stats.pendingApprovals > 0 && (
                  <Badge variant="destructive" className="ml-2">{stats.pendingApprovals}</Badge>
                )}
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/admin/candidates">
                <Users className="w-4 h-4 mr-2" />
                Manage Candidates
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/admin/activity">
                <Calendar className="w-4 h-4 mr-2" />
                View Activity
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activities.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No recent activity</p>
          ) : (
            <div className="space-y-4">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#e87e0d]/10 flex items-center justify-center">
                      <ClipboardList className="w-4 h-4 text-[#e87e0d]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{activity.action}</p>
                      <p className="text-xs text-muted-foreground">
                        {activity.entity_type && `Entity: ${activity.entity_type}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">{activity.profiles?.full_name || 'System'}</p>
                    <p className="text-xs text-muted-foreground">{formatDateTime(activity.created_at)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
