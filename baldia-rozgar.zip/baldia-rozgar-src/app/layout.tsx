import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Baldia Rozgar - Employment Platform',
  description: 'Centralized employment platform for industries in Baldia Town, Karachi',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
