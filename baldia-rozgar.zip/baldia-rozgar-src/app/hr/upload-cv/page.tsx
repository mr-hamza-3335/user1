'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, File, X, Trash2, Loader2, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { formatDate } from '@/lib/utils';
import type { Candidate } from '@/lib/types';

interface CandidateCV {
  id: string;
  file_name: string;
  file_size: number;
  uploaded_at: string;
}

export default function UploadCV() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const preselectedCandidate = searchParams.get('candidate');
  
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<string>(preselectedCandidate || '');
  const [candidateCVs, setCandidateCVs] = useState<CandidateCV[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const supabase = createClient();

  useEffect(() => {
    fetchCandidates();
  }, []);

  useEffect(() => {
    if (selectedCandidate) {
      fetchCandidateCVs(selectedCandidate);
    }
  }, [selectedCandidate]);

  const fetchCandidates = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      const { data, error } = await supabase
        .from('candidates')
        .select('id, full_name')
        .eq('added_by', userData.user.id)
        .order('full_name', { ascending: true });

      if (error) throw error;
      setCandidates(data || []);
    } catch (error) {
      console.error('Error fetching candidates:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCandidateCVs = async (candidateId: string) => {
    try {
      const { data, error } = await supabase
        .from('candidate_cvs')
        .select('*')
        .eq('candidate_id', candidateId)
        .order('uploaded_at', { ascending: false });

      if (error) throw error;
      setCandidateCVs(data || []);
    } catch (error) {
      console.error('Error fetching CVs:', error);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedCandidate) return;

    // Validate file type
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      alert('Only PDF, DOC, and DOCX files are allowed');
      return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setUploading(true);

    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error('Not authenticated');

      // Upload file to storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${selectedCandidate}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('cvs')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('cvs')
        .getPublicUrl(filePath);

      // Save CV record
      const { error: cvError } = await supabase.from('candidate_cvs').insert({
        candidate_id: selectedCandidate,
        file_url: publicUrl,
        file_name: file.name,
        file_size: file.size,
        uploaded_by: userData.user.id,
      });

      if (cvError) throw cvError;

      // Log activity
      await supabase.from('activity_logs').insert({
        action: 'Uploaded CV',
        entity_type: 'candidate_cv',
        entity_id: selectedCandidate,
      });

      fetchCandidateCVs(selectedCandidate);
    } catch (error) {
      console.error('Error uploading CV:', error);
      alert('Error uploading CV. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteCV = async (cvId: string) => {
    if (!confirm('Are you sure you want to delete this CV?')) return;

    try {
      const { error } = await supabase
        .from('candidate_cvs')
        .delete()
        .eq('id', cvId);

      if (error) throw error;

      fetchCandidateCVs(selectedCandidate);
    } catch (error) {
      console.error('Error deleting CV:', error);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const filteredCandidates = candidates.filter((c) =>
    c.full_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
          Upload CV
        </h1>
        <p className="text-muted-foreground">Upload and manage candidate CVs</p>
      </div>

      {/* Candidate Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Candidate</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search candidates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
            <SelectTrigger>
              <SelectValue placeholder="Select a candidate" />
            </SelectTrigger>
            <SelectContent>
              {filteredCandidates.map((candidate) => (
                <SelectItem key={candidate.id} value={candidate.id}>
                  {candidate.full_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Upload Area */}
      {selectedCandidate && (
        <Card>
          <CardHeader>
            <CardTitle>Upload New CV</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-[#e87e0d] transition-colors">
              <input
                type="file"
                id="cv-upload"
                accept=".pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading}
              />
              <label htmlFor="cv-upload" className="cursor-pointer">
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium mb-2">
                  {uploading ? 'Uploading...' : 'Click to upload CV'}
                </p>
                <p className="text-sm text-muted-foreground">
                  PDF, DOC, or DOCX up to 5MB
                </p>
              </label>
              {uploading && (
                <Loader2 className="w-6 h-6 animate-spin mx-auto mt-4 text-[#e87e0d]" />
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Uploaded CVs */}
      {selectedCandidate && (
        <Card>
          <CardHeader>
            <CardTitle>Uploaded CVs ({candidateCVs.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {candidateCVs.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No CVs uploaded yet</p>
            ) : (
              <div className="space-y-3">
                {candidateCVs.map((cv) => (
                  <div
                    key={cv.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <File className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">{cv.file_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatFileSize(cv.file_size)} • Uploaded {formatDate(cv.uploaded_at)}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-600 hover:text-red-700"
                        onClick={() => handleDeleteCV(cv.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
