'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Upload, Plus, FileText } from 'lucide-react';
import Link from 'next/link';
import { formatDate } from '@/lib/utils';
import type { Candidate } from '@/lib/types';

export default function HRDashboard() {
  const [stats, setStats] = useState({
    myCandidates: 0,
    cvsThisWeek: 0,
  });
  const [recentCandidates, setRecentCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Fetch candidates added by this HR
      const { count: candidatesCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true })
        .eq('added_by', userData.user.id);

      // Fetch CVs uploaded this week
      const startOfWeek = new Date();
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
      startOfWeek.setHours(0, 0, 0, 0);

      const { count: cvsCount } = await supabase
        .from('candidate_cvs')
        .select('*', { count: 'exact', head: true })
        .eq('uploaded_by', userData.user.id)
        .gte('uploaded_at', startOfWeek.toISOString());

      setStats({
        myCandidates: candidatesCount || 0,
        cvsThisWeek: cvsCount || 0,
      });

      // Fetch recent candidates
      const { data: candidatesData } = await supabase
        .from('candidates')
        .select('*')
        .eq('added_by', userData.user.id)
        .order('created_at', { ascending: false })
        .limit(5);

      setRecentCandidates(candidatesData || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
          HR Dashboard
        </h1>
        <p className="text-muted-foreground">Welcome to your HR dashboard</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Candidates I Added</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.myCandidates}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">CVs Uploaded This Week</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.cvsThisWeek}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <Upload className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
              <Link href="/hr/candidates/add">
                <Plus className="w-4 h-4 mr-2" />
                Add Candidate
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/hr/upload-cv">
                <Upload className="w-4 h-4 mr-2" />
                Upload CV
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Candidates */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Candidates I Added</CardTitle>
          <Button asChild variant="ghost" size="sm">
            <Link href="/hr/candidates">View All</Link>
          </Button>
        </CardHeader>
        <CardContent>
          {recentCandidates.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No candidates added yet</p>
          ) : (
            <div className="space-y-4">
              {recentCandidates.map((candidate) => (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#e87e0d]/10 flex items-center justify-center">
                      <Users className="w-5 h-5 text-[#e87e0d]" />
                    </div>
                    <div>
                      <p className="font-medium">{candidate.full_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {candidate.role_category} • {candidate.experience_years} years exp.
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">{formatDate(candidate.created_at)}</p>
                    <p className="text-xs text-muted-foreground capitalize">{candidate.availability}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
