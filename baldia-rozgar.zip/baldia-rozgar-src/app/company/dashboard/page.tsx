'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, Calendar, CheckCircle, Users, Search } from 'lucide-react';
import Link from 'next/link';
import { formatDate } from '@/lib/utils';
import type { Candidate } from '@/lib/types';

interface DashboardStats {
  myShortlist: number;
  interviewsSent: number;
  hiredCount: number;
  availableCandidates: number;
}

export default function CompanyDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    myShortlist: 0,
    interviewsSent: 0,
    hiredCount: 0,
    availableCandidates: 0,
  });
  const [recentShortlist, setRecentShortlist] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (!companyData) return;

      const companyId = companyData.id;

      // Fetch shortlist count
      const { count: shortlistCount } = await supabase
        .from('shortlists')
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId);

      // Fetch interviews count
      const { count: interviewsCount } = await supabase
        .from('interview_requests')
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId);

      // Fetch hired count
      const { count: hiredCount } = await supabase
        .from('hiring_records')
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId);

      // Fetch available candidates
      const { count: availableCount } = await supabase
        .from('candidates')
        .select('*', { count: 'exact', head: true })
        .eq('availability', 'available');

      setStats({
        myShortlist: shortlistCount || 0,
        interviewsSent: interviewsCount || 0,
        hiredCount: hiredCount || 0,
        availableCandidates: availableCount || 0,
      });

      // Fetch recent shortlist
      const { data: shortlistData } = await supabase
        .from('shortlists')
        .select('candidates(*)')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false })
        .limit(5);

      const candidates = shortlistData?.map((item: any) => item.candidates) || [];
      setRecentShortlist(candidates);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
          Company Dashboard
        </h1>
        <p className="text-muted-foreground">Welcome to your company dashboard</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">My Shortlist</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.myShortlist}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Interviews Sent</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.interviewsSent}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Hired Count</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.hiredCount}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Available Candidates</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.availableCandidates}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Big Search Button */}
      <Card className="bg-gradient-to-r from-[#e87e0d] to-[#f5a623] text-white">
        <CardContent className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Find Your Next Employee</h2>
          <p className="mb-6 opacity-90">Browse our database of pre-verified candidates</p>
          <Button asChild size="lg" variant="secondary" className="bg-white text-[#e87e0d] hover:bg-gray-100">
            <Link href="/company/search">
              <Search className="w-5 h-5 mr-2" />
              Search Candidates
            </Link>
          </Button>
        </CardContent>
      </Card>

      {/* Recent Shortlist */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recently Shortlisted</CardTitle>
          <Button asChild variant="ghost" size="sm">
            <Link href="/company/shortlist">View All</Link>
          </Button>
        </CardHeader>
        <CardContent>
          {recentShortlist.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No candidates shortlisted yet</p>
              <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
                <Link href="/company/search">Start Searching</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {recentShortlist.map((candidate) => (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#e87e0d]/10 flex items-center justify-center">
                      <Users className="w-5 h-5 text-[#e87e0d]" />
                    </div>
                    <div>
                      <p className="font-medium">{candidate.full_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {candidate.role_category} • {candidate.experience_years} years exp.
                      </p>
                    </div>
                  </div>
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/company/candidates/${candidate.id}`}>View Profile</Link>
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
