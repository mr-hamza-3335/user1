'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Eye, Calendar, Trash2, Star } from 'lucide-react';
import Link from 'next/link';
import { formatDate } from '@/lib/utils';
import type { Candidate } from '@/lib/types';

interface ShortlistItem {
  id: string;
  candidate_id: string;
  notes: string | null;
  created_at: string;
  candidates: Candidate;
}

export default function CompanyShortlist() {
  const [shortlist, setShortlist] = useState<ShortlistItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    fetchShortlist();
  }, []);

  const fetchShortlist = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (!companyData) return;
      setCompanyId(companyData.id);

      // Fetch shortlist with candidate details
      const { data, error } = await supabase
        .from('shortlists')
        .select('*, candidates(*)')
        .eq('company_id', companyData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setShortlist(data || []);
    } catch (error) {
      console.error('Error fetching shortlist:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (id: string) => {
    if (!confirm('Are you sure you want to remove this candidate from your shortlist?')) return;

    try {
      const { error } = await supabase.from('shortlists').delete().eq('id', id);
      if (error) throw error;
      fetchShortlist();
    } catch (error) {
      console.error('Error removing from shortlist:', error);
    }
  };

  const handleBulkRemove = async () => {
    if (!confirm(`Are you sure you want to remove ${selectedItems.length} candidates from your shortlist?`)) return;

    try {
      const { error } = await supabase
        .from('shortlists')
        .delete()
        .in('id', selectedItems);
      
      if (error) throw error;
      setSelectedItems([]);
      fetchShortlist();
    } catch (error) {
      console.error('Error bulk removing:', error);
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    if (selectedItems.length === shortlist.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(shortlist.map((item) => item.id));
    }
  };

  const updateNotes = async (id: string, notes: string) => {
    try {
      const { error } = await supabase
        .from('shortlists')
        .update({ notes })
        .eq('id', id);
      
      if (error) throw error;
      fetchShortlist();
    } catch (error) {
      console.error('Error updating notes:', error);
    }
  };

  const getAvailabilityBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge variant="success">Available</Badge>;
      case 'hired':
        return <Badge variant="secondary">Hired</Badge>;
      case 'notice_period':
        return <Badge variant="warning">Notice Period</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            My Shortlist
          </h1>
          <p className="text-muted-foreground">Candidates you have shortlisted</p>
        </div>
        {selectedItems.length > 0 && (
          <Button variant="destructive" onClick={handleBulkRemove}>
            <Trash2 className="w-4 h-4 mr-2" />
            Remove Selected ({selectedItems.length})
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10">
                  <Checkbox
                    checked={selectedItems.length === shortlist.length && shortlist.length > 0}
                    onCheckedChange={toggleAll}
                  />
                </TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Skills</TableHead>
                <TableHead>Availability</TableHead>
                <TableHead>Date Added</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {shortlist.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    <div className="space-y-4">
                      <Star className="w-12 h-12 mx-auto text-gray-300" />
                      <p>No candidates in your shortlist</p>
                      <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
                        <Link href="/company/search">Browse Candidates</Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                shortlist.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={() => toggleSelection(item.id)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{item.candidates.full_name}</TableCell>
                    <TableCell>{item.candidates.role_category}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {item.candidates.skills?.slice(0, 3).map((skill, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>{getAvailabilityBadge(item.candidates.availability)}</TableCell>
                    <TableCell>{formatDate(item.created_at)}</TableCell>
                    <TableCell>
                      <Input
                        value={item.notes || ''}
                        onChange={(e) => updateNotes(item.id, e.target.value)}
                        placeholder="Add notes..."
                        className="w-40 text-sm"
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          asChild
                        >
                          <Link href={`/company/candidates/${item.candidate_id}`}>
                            <Eye className="w-4 h-4" />
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          asChild
                        >
                          <Link href={`/company/interviews/request?candidate=${item.candidate_id}`}>
                            <Calendar className="w-4 h-4" />
                          </Link>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => handleRemove(item.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
