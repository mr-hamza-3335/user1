'use client';

import { useState, useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Calendar, Plus, Video, Phone, MapPin, Eye } from 'lucide-react';
import Link from 'next/link';
import { formatDate } from '@/lib/utils';

interface InterviewRequest {
  id: string;
  candidate_id: string;
  proposed_date: string;
  proposed_time: string;
  interview_type: 'in_person' | 'phone' | 'video';
  location: string | null;
  message: string | null;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  created_at: string;
  candidates: { full_name: string; role_category: string };
}

export default function CompanyInterviews() {
  const [interviews, setInterviews] = useState<InterviewRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchInterviews();
  }, []);

  const fetchInterviews = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (!companyData) return;

      // Fetch interviews
      const { data, error } = await supabase
        .from('interview_requests')
        .select('*, candidates(full_name, role_category)')
        .eq('company_id', companyData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInterviews(data || []);
    } catch (error) {
      console.error('Error fetching interviews:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <Badge variant="success">Confirmed</Badge>;
      case 'completed':
        return <Badge className="bg-blue-100 text-blue-800">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="warning">Pending</Badge>;
    }
  };

  const getInterviewTypeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="w-4 h-4" />;
      case 'phone':
        return <Phone className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  const InterviewTable = ({ status }: { status: string }) => {
    const filtered = interviews.filter((i) => i.status === status);

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Candidate</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Time</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filtered.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                No {status} interviews
              </TableCell>
            </TableRow>
          ) : (
            filtered.map((interview) => (
              <TableRow key={interview.id}>
                <TableCell className="font-medium">{interview.candidates.full_name}</TableCell>
                <TableCell>{interview.candidates.role_category}</TableCell>
                <TableCell>{formatDate(interview.proposed_date)}</TableCell>
                <TableCell>{interview.proposed_time}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {getInterviewTypeIcon(interview.interview_type)}
                    <span className="capitalize">{interview.interview_type.replace('_', ' ')}</span>
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(interview.status)}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" asChild>
                    <Link href={`/company/candidates/${interview.candidate_id}`}>
                      <Eye className="w-4 h-4" />
                    </Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  const pendingCount = interviews.filter((i) => i.status === 'pending').length;
  const confirmedCount = interviews.filter((i) => i.status === 'confirmed').length;
  const completedCount = interviews.filter((i) => i.status === 'completed').length;
  const cancelledCount = interviews.filter((i) => i.status === 'cancelled').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Interview Requests
          </h1>
          <p className="text-muted-foreground">Manage your interview requests</p>
        </div>
        <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
          <Link href="/company/interviews/request">
            <Plus className="w-4 h-4 mr-2" />
            New Request
          </Link>
        </Button>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList>
          <TabsTrigger value="pending">
            Pending ({pendingCount})
          </TabsTrigger>
          <TabsTrigger value="confirmed">
            Confirmed ({confirmedCount})
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed ({completedCount})
          </TabsTrigger>
          <TabsTrigger value="cancelled">
            Cancelled ({cancelledCount})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <InterviewTable status="pending" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="confirmed" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <InterviewTable status="confirmed" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <InterviewTable status="completed" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cancelled" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <InterviewTable status="cancelled" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
