'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ArrowLeft, Loader2, Calendar } from 'lucide-react';
import Link from 'next/link';
import type { Candidate } from '@/lib/types';

export default function RequestInterview() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const preselectedCandidate = searchParams.get('candidate');
  
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [shortlistedIds, setShortlistedIds] = useState<string[]>([]);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    candidateId: preselectedCandidate || '',
    proposedDate: '',
    proposedTime: '',
    interviewType: 'in_person',
    location: '',
    message: '',
  });

  const supabase = createClient();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (companyData) {
        setCompanyId(companyData.id);
        
        // Fetch shortlisted candidates
        const { data: shortlistData } = await supabase
          .from('shortlists')
          .select('candidate_id')
          .eq('company_id', companyData.id);
        
        const ids = shortlistData?.map((s) => s.candidate_id) || [];
        setShortlistedIds(ids);

        // Fetch shortlisted candidate details
        if (ids.length > 0) {
          const { data: candidatesData } = await supabase
            .from('candidates')
            .select('id, full_name, role_category')
            .in('id', ids);
          
          setCandidates(candidatesData || []);
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) return;

    setSubmitting(true);
    try {
      const { error } = await supabase.from('interview_requests').insert({
        company_id: companyId,
        candidate_id: formData.candidateId,
        proposed_date: formData.proposedDate,
        proposed_time: formData.proposedTime,
        interview_type: formData.interviewType as 'in_person' | 'phone' | 'video',
        location: formData.location || null,
        message: formData.message || null,
        status: 'pending',
      });

      if (error) throw error;

      router.push('/company/interviews');
    } catch (error) {
      console.error('Error creating interview request:', error);
      alert('Error creating interview request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/company/interviews">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Request Interview
          </h1>
          <p className="text-muted-foreground">Send an interview request to a candidate</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="candidate">Select Candidate *</Label>
              <Select
                value={formData.candidateId}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, candidateId: value }))}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a candidate from your shortlist" />
                </SelectTrigger>
                <SelectContent>
                  {candidates.map((candidate) => (
                    <SelectItem key={candidate.id} value={candidate.id}>
                      {candidate.full_name} - {candidate.role_category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {candidates.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  You need to shortlist candidates first.{' '}
                  <Link href="/company/search" className="text-[#e87e0d] hover:underline">
                    Browse candidates
                  </Link>
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Proposed Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.proposedDate}
                  onChange={(e) => setFormData((prev) => ({ ...prev, proposedDate: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time">Proposed Time *</Label>
                <Input
                  id="time"
                  type="time"
                  value={formData.proposedTime}
                  onChange={(e) => setFormData((prev) => ({ ...prev, proposedTime: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Interview Type *</Label>
              <RadioGroup
                value={formData.interviewType}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, interviewType: value }))}
                className="flex flex-wrap gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="in_person" id="in_person" />
                  <Label htmlFor="in_person" className="font-normal cursor-pointer">
                    In Person
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="phone" id="phone" />
                  <Label htmlFor="phone" className="font-normal cursor-pointer">
                    Phone
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="video" id="video" />
                  <Label htmlFor="video" className="font-normal cursor-pointer">
                    Video Call
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {formData.interviewType === 'in_person' && (
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="Enter interview location"
                  value={formData.location}
                  onChange={(e) => setFormData((prev) => ({ ...prev, location: e.target.value }))}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                placeholder="Add any additional information or instructions..."
                value={formData.message}
                onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                className="min-h-[100px]"
              />
            </div>

            <div className="flex justify-end gap-4">
              <Button variant="outline" asChild>
                <Link href="/company/interviews">Cancel</Link>
              </Button>
              <Button
                type="submit"
                className="bg-[#e87e0d] hover:bg-[#d16f0a]"
                disabled={submitting || !formData.candidateId}
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Calendar className="w-4 h-4 mr-2" />
                    Send Request
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
