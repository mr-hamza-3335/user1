'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { CheckCircle, Download, FileText, Plus } from 'lucide-react';
import Link from 'next/link';
import { formatCurrency, formatDate } from '@/lib/utils';

interface HiringRecord {
  id: string;
  candidate_id: string;
  position_title: string | null;
  hired_date: string | null;
  salary_offered: number | null;
  status: 'hired' | 'rejected' | 'offer_pending';
  created_at: string;
  candidates: { full_name: string; role_category: string };
}

export default function CompanyHired() {
  const searchParams = useSearchParams();
  const [hiringRecords, setHiringRecords] = useState<HiringRecord[]>([]);
  const [stats, setStats] = useState({ total: 0, hired: 0, offerPending: 0, rejected: 0 });
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchHiringRecords();
  }, []);

  const fetchHiringRecords = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (!companyData) return;

      // Fetch hiring records
      const { data, error } = await supabase
        .from('hiring_records')
        .select('*, candidates(full_name, role_category)')
        .eq('company_id', companyData.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setHiringRecords(data || []);

      // Calculate stats
      const records = data || [];
      setStats({
        total: records.length,
        hired: records.filter((r) => r.status === 'hired').length,
        offerPending: records.filter((r) => r.status === 'offer_pending').length,
        rejected: records.filter((r) => r.status === 'rejected').length,
      });
    } catch (error) {
      console.error('Error fetching hiring records:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'hired':
        return <Badge variant="success">Hired</Badge>;
      case 'offer_pending':
        return <Badge variant="warning">Offer Pending</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  const exportToPDF = () => {
    // In a real app, this would generate a PDF
    alert('PDF export feature coming soon!');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Hiring Records
          </h1>
          <p className="text-muted-foreground">Track your hiring decisions</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={exportToPDF}>
            <FileText className="w-4 h-4 mr-2" />
            Export to PDF
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Records</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.total}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Hired</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.hired}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Offer Pending</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.offerPending}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Rejected</p>
                <p className="text-3xl font-bold mt-1" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {stats.rejected}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hiring Records Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Candidate</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Hired Date</TableHead>
                <TableHead>Salary Offered</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {hiringRecords.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    <div className="space-y-4">
                      <CheckCircle className="w-12 h-12 mx-auto text-gray-300" />
                      <p>No hiring records yet</p>
                      <Button asChild className="bg-[#e87e0d] hover:bg-[#d16f0a]">
                        <Link href="/company/search">Find Candidates</Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                hiringRecords.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{record.candidates.full_name}</TableCell>
                    <TableCell>{record.position_title || 'N/A'}</TableCell>
                    <TableCell>{formatDate(record.hired_date)}</TableCell>
                    <TableCell>{formatCurrency(record.salary_offered)}</TableCell>
                    <TableCell>{getStatusBadge(record.status)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
