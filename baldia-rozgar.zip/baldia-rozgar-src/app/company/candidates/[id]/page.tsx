'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Star, Calendar, CheckCircle, Phone, MapPin, Briefcase, GraduationCap, Languages, FileText, Download } from 'lucide-react';
import Link from 'next/link';
import { formatCurrency, formatDate } from '@/lib/utils';
import type { Candidate, CandidateCV } from '@/lib/types';

export default function CandidateProfile() {
  const params = useParams();
  const router = useRouter();
  const candidateId = params.id as string;
  
  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [cvs, setCvs] = useState<CandidateCV[]>([]);
  const [isShortlisted, setIsShortlisted] = useState(false);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    fetchData();
  }, [candidateId]);

  const fetchData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (companyData) {
        setCompanyId(companyData.id);
        
        // Check if shortlisted
        const { data: shortlistData } = await supabase
          .from('shortlists')
          .select('id')
          .eq('company_id', companyData.id)
          .eq('candidate_id', candidateId)
          .single();
        
        setIsShortlisted(!!shortlistData);
      }

      // Fetch candidate
      const { data: candidateData, error: candidateError } = await supabase
        .from('candidates')
        .select('*')
        .eq('id', candidateId)
        .single();

      if (candidateError) throw candidateError;
      setCandidate(candidateData);

      // Fetch CVs
      const { data: cvsData } = await supabase
        .from('candidate_cvs')
        .select('*')
        .eq('candidate_id', candidateId)
        .order('uploaded_at', { ascending: false });

      setCvs(cvsData || []);
    } catch (error) {
      console.error('Error fetching candidate:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleShortlist = async () => {
    if (!companyId) return;

    try {
      if (isShortlisted) {
        await supabase
          .from('shortlists')
          .delete()
          .eq('company_id', companyId)
          .eq('candidate_id', candidateId);
        setIsShortlisted(false);
      } else {
        await supabase.from('shortlists').insert({
          company_id: companyId,
          candidate_id: candidateId,
        });
        setIsShortlisted(true);
      }
    } catch (error) {
      console.error('Error toggling shortlist:', error);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = ['bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-green-500', 'bg-emerald-500', 'bg-teal-500', 'bg-cyan-500', 'bg-sky-500', 'bg-blue-500', 'bg-indigo-500', 'bg-violet-500', 'bg-purple-500', 'bg-fuchsia-500', 'bg-pink-500', 'bg-rose-500'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const getAvailabilityBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge variant="success">Available</Badge>;
      case 'hired':
        return <Badge variant="secondary">Hired</Badge>;
      case 'notice_period':
        return <Badge variant="warning">Notice Period</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Candidate not found</p>
        <Button asChild className="mt-4">
          <Link href="/company/search">Back to Search</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/company/search">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
            Candidate Profile
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Basic Info */}
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div
                className={`w-24 h-24 rounded-full ${getAvatarColor(
                  candidate.full_name
                )} flex items-center justify-center text-white font-bold text-3xl mx-auto`}
              >
                {getInitials(candidate.full_name)}
              </div>
              <h2 className="text-2xl font-bold mt-4">{candidate.full_name}</h2>
              <p className="text-muted-foreground">{candidate.role_category}</p>
              <div className="mt-3">{getAvailabilityBadge(candidate.availability)}</div>
              
              {isShortlisted && (
                <div className="mt-4 flex items-center justify-center gap-2 text-green-600">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">{candidate.phone || 'No phone'}</span>
                </div>
              )}

              {candidate.area && (
                <div className="mt-2 flex items-center justify-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{candidate.area}</span>
                </div>
              )}

              {/* Skills */}
              <div className="mt-4">
                <h4 className="text-sm font-medium mb-2">Skills</h4>
                <div className="flex flex-wrap justify-center gap-1">
                  {candidate.skills?.map((skill, idx) => (
                    <Badge key={idx} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Languages */}
              {candidate.languages && candidate.languages.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2 flex items-center justify-center gap-2">
                    <Languages className="w-4 h-4" />
                    Languages
                  </h4>
                  <div className="flex flex-wrap justify-center gap-1">
                    {candidate.languages.map((lang, idx) => (
                      <Badge key={idx} variant="outline">
                        {lang}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <Button
                variant={isShortlisted ? 'secondary' : 'outline'}
                className="w-full"
                onClick={toggleShortlist}
              >
                <Star className={`w-4 h-4 mr-2 ${isShortlisted ? 'fill-yellow-400' : ''}`} />
                {isShortlisted ? 'Remove from Shortlist' : 'Add to Shortlist'}
              </Button>
              <Button asChild className="w-full bg-[#e87e0d] hover:bg-[#d16f0a]">
                <Link href={`/company/interviews/request?candidate=${candidate.id}`}>
                  <Calendar className="w-4 h-4 mr-2" />
                  Request Interview
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link href={`/company/hired?candidate=${candidate.id}`}>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark as Hired
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Personal Information */}
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Father Name</p>
                <p className="font-medium">{candidate.father_name || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">CNIC</p>
                <p className="font-medium">{candidate.cnic || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Date of Birth</p>
                <p className="font-medium">{formatDate(candidate.date_of_birth)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gender</p>
                <p className="font-medium capitalize">{candidate.gender || 'N/A'}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-muted-foreground">Address</p>
                <p className="font-medium">{candidate.address || 'N/A'}</p>
              </div>
            </CardContent>
          </Card>

          {/* Education */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Education
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-muted-foreground">Education Level</p>
                  <p className="font-medium">{candidate.education || 'Not specified'}</p>
                </div>
                {candidate.education_detail && (
                  <div>
                    <p className="text-sm text-muted-foreground">Details</p>
                    <p className="font-medium">{candidate.education_detail}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Experience */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Experience
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Years of Experience</p>
                  <p className="font-medium">{candidate.experience_years} years</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Salary</p>
                  <p className="font-medium">{formatCurrency(candidate.current_salary)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expected Salary</p>
                  <p className="font-medium">{formatCurrency(candidate.expected_salary)}</p>
                </div>
              </div>
              {candidate.experience_detail && (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">Experience Details</p>
                  <p className="font-medium">{candidate.experience_detail}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notes */}
          {candidate.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{candidate.notes}</p>
              </CardContent>
            </Card>
          )}

          {/* CV Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                CV / Resume
              </CardTitle>
            </CardHeader>
            <CardContent>
              {cvs.length === 0 ? (
                <div className="text-center py-8 bg-gray-50 rounded-lg">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                  <p className="text-muted-foreground">CV not uploaded yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {cvs.map((cv) => (
                    <div
                      key={cv.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-blue-600" />
                        <div>
                          <p className="font-medium">{cv.file_name}</p>
                          <p className="text-sm text-muted-foreground">
                            Uploaded {formatDate(cv.uploaded_at)}
                          </p>
                        </div>
                      </div>
                      <Button asChild variant="outline" size="sm">
                        <a href={cv.file_url} target="_blank" rel="noopener noreferrer">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </a>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
