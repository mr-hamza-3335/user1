'use client';

import { useState, useEffect, useCallback } from 'react';
import { createClient } from '@/lib/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Search, Star, MapPin, Briefcase, GraduationCap, X, Filter } from 'lucide-react';
import Link from 'next/link';
import { debounce } from '@/lib/utils';
import type { Candidate } from '@/lib/types';

const roleCategories = [
  'All',
  'Production',
  'Quality Control',
  'Maintenance',
  'Warehouse',
  'Administration',
  'Sales',
  'Accounting',
  'Security',
  'Driver',
  'Helper',
  'Supervisor',
  'Manager',
  'Other',
];

const educationLevels = ['All', 'No Formal Education', 'Primary', 'Middle', 'Matric', 'Intermediate', 'Diploma', 'Bachelor', 'Master'];

const sortOptions = [
  { value: 'newest', label: 'Newest First' },
  { value: 'experience_high', label: 'Experience: High to Low' },
  { value: 'experience_low', label: 'Experience: Low to High' },
];

export default function SearchCandidates() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [filteredCandidates, setFilteredCandidates] = useState<Candidate[]>([]);
  const [shortlistedIds, setShortlistedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState<string | null>(null);
  
  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [experienceMin, setExperienceMin] = useState('');
  const [experienceMax, setExperienceMax] = useState('');
  const [educationFilter, setEducationFilter] = useState('All');
  const [availabilityFilter, setAvailabilityFilter] = useState('available');
  const [areaFilter, setAreaFilter] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('newest');
  
  const supabase = createClient();

  useEffect(() => {
    fetchInitialData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [candidates, searchQuery, roleFilter, experienceMin, experienceMax, educationFilter, availabilityFilter, areaFilter, selectedSkills, sortBy]);

  const fetchInitialData = async () => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) return;

      // Get company ID
      const { data: companyData } = await supabase
        .from('companies')
        .select('id')
        .eq('user_id', userData.user.id)
        .single();

      if (companyData) {
        setCompanyId(companyData.id);
        
        // Fetch shortlisted candidates
        const { data: shortlistData } = await supabase
          .from('shortlists')
          .select('candidate_id')
          .eq('company_id', companyData.id);
        
        setShortlistedIds(shortlistData?.map((s) => s.candidate_id) || []);
      }

      // Fetch all available candidates
      const { data, error } = await supabase
        .from('candidates')
        .select('*')
        .eq('availability', 'available')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCandidates(data || []);
      setFilteredCandidates(data || []);
    } catch (error) {
      console.error('Error fetching candidates:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...candidates];

    // Text search (name, skills, role)
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (c) =>
          c.full_name.toLowerCase().includes(query) ||
          c.role_category.toLowerCase().includes(query) ||
          c.skills?.some((s) => s.toLowerCase().includes(query))
      );
    }

    // Role filter
    if (roleFilter !== 'All') {
      filtered = filtered.filter((c) => c.role_category === roleFilter);
    }

    // Experience range
    if (experienceMin) {
      filtered = filtered.filter((c) => c.experience_years >= parseInt(experienceMin));
    }
    if (experienceMax) {
      filtered = filtered.filter((c) => c.experience_years <= parseInt(experienceMax));
    }

    // Education filter
    if (educationFilter !== 'All') {
      filtered = filtered.filter((c) => c.education === educationFilter);
    }

    // Availability filter
    if (availabilityFilter) {
      filtered = filtered.filter((c) => c.availability === availabilityFilter);
    }

    // Area filter
    if (areaFilter) {
      filtered = filtered.filter((c) =>
        c.area?.toLowerCase().includes(areaFilter.toLowerCase())
      );
    }

    // Skills filter
    if (selectedSkills.length > 0) {
      filtered = filtered.filter((c) =>
        selectedSkills.some((skill) => c.skills?.includes(skill))
      );
    }

    // Sorting
    switch (sortBy) {
      case 'experience_high':
        filtered.sort((a, b) => b.experience_years - a.experience_years);
        break;
      case 'experience_low':
        filtered.sort((a, b) => a.experience_years - b.experience_years);
        break;
      case 'newest':
      default:
        filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }

    setFilteredCandidates(filtered);
  };

  const debouncedSearch = useCallback(
    debounce((value: string) => {
      setSearchQuery(value);
    }, 300),
    []
  );

  const toggleShortlist = async (candidateId: string) => {
    if (!companyId) return;

    try {
      if (shortlistedIds.includes(candidateId)) {
        // Remove from shortlist
        await supabase
          .from('shortlists')
          .delete()
          .eq('company_id', companyId)
          .eq('candidate_id', candidateId);
        
        setShortlistedIds((prev) => prev.filter((id) => id !== candidateId));
      } else {
        // Add to shortlist
        await supabase.from('shortlists').insert({
          company_id: companyId,
          candidate_id: candidateId,
        });
        
        setShortlistedIds((prev) => [...prev, candidateId]);
      }
    } catch (error) {
      console.error('Error toggling shortlist:', error);
    }
  };

  const clearAllFilters = () => {
    setSearchQuery('');
    setRoleFilter('All');
    setExperienceMin('');
    setExperienceMax('');
    setEducationFilter('All');
    setAvailabilityFilter('available');
    setAreaFilter('');
    setSelectedSkills([]);
    setSortBy('newest');
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = ['bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-green-500', 'bg-emerald-500', 'bg-teal-500', 'bg-cyan-500', 'bg-sky-500', 'bg-blue-500', 'bg-indigo-500', 'bg-violet-500', 'bg-purple-500', 'bg-fuchsia-500', 'bg-pink-500', 'bg-rose-500'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const getAvailabilityBadge = (status: string) => {
    switch (status) {
      case 'available':
        return <Badge variant="success">Available</Badge>;
      case 'hired':
        return <Badge variant="secondary">Hired</Badge>;
      case 'notice_period':
        return <Badge variant="warning">Notice Period</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  // Extract all unique skills from candidates
  const allSkills = Array.from(
    new Set(candidates.flatMap((c) => c.skills || []))
  ).slice(0, 20);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87e0d]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-[#1C2533]" style={{ fontFamily: 'Bebas Neue, sans-serif' }}>
          Search Candidates
        </h1>
        <p className="text-muted-foreground">Find the perfect candidate for your company</p>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search by name, skills, or role..."
              onChange={(e) => debouncedSearch(e.target.value)}
              className="pl-12 h-12 text-lg"
            />
          </div>

          {/* Filter Row */}
          <div className="flex flex-wrap gap-3">
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-40">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                {roleCategories.map((role) => (
                  <SelectItem key={role} value={role}>
                    {role}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Input
                placeholder="Min Exp"
                type="number"
                value={experienceMin}
                onChange={(e) => setExperienceMin(e.target.value)}
                className="w-24"
              />
              <span className="text-muted-foreground">-</span>
              <Input
                placeholder="Max Exp"
                type="number"
                value={experienceMax}
                onChange={(e) => setExperienceMax(e.target.value)}
                className="w-24"
              />
              <span className="text-sm text-muted-foreground">years</span>
            </div>

            <Select value={educationFilter} onValueChange={setEducationFilter}>
              <SelectTrigger className="w-40">
                <GraduationCap className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Education" />
              </SelectTrigger>
              <SelectContent>
                {educationLevels.map((edu) => (
                  <SelectItem key={edu} value={edu}>
                    {edu}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Input
              placeholder="Area/Location"
              value={areaFilter}
              onChange={(e) => setAreaFilter(e.target.value)}
              className="w-40"
            />

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={clearAllFilters}>
              <X className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          </div>

          {/* Skills Filter */}
          {allSkills.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-muted-foreground py-1">Skills:</span>
              {allSkills.map((skill) => (
                <Badge
                  key={skill}
                  variant={selectedSkills.includes(skill) ? 'default' : 'outline'}
                  className={`cursor-pointer ${selectedSkills.includes(skill) ? 'bg-[#e87e0d]' : ''}`}
                  onClick={() => {
                    setSelectedSkills((prev) =>
                      prev.includes(skill)
                        ? prev.filter((s) => s !== skill)
                        : [...prev, skill]
                    );
                  }}
                >
                  {skill}
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-muted-foreground">
          Showing <strong>{filteredCandidates.length}</strong> of <strong>{candidates.length}</strong> candidates
        </p>
      </div>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredCandidates.map((candidate) => (
          <Card key={candidate.id} className="hover:shadow-lg transition-shadow relative">
            <CardContent className="p-5">
              {/* Shortlist Button */}
              <button
                onClick={() => toggleShortlist(candidate.id)}
                className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <Star
                  className={`w-5 h-5 ${
                    shortlistedIds.includes(candidate.id)
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-gray-400'
                  }`}
                />
              </button>

              <div className="flex items-start gap-4">
                {/* Avatar */}
                <div
                  className={`w-14 h-14 rounded-full ${getAvatarColor(
                    candidate.full_name
                  )} flex items-center justify-center text-white font-bold text-lg`}
                >
                  {getInitials(candidate.full_name)}
                </div>

                <div className="flex-1 min-w-0 pr-8">
                  <h3 className="font-semibold text-lg truncate">{candidate.full_name}</h3>
                  <p className="text-sm text-muted-foreground">{candidate.role_category}</p>
                  <div className="mt-2">{getAvailabilityBadge(candidate.availability)}</div>
                </div>
              </div>

              {/* Skills */}
              <div className="mt-4 flex flex-wrap gap-1">
                {candidate.skills?.slice(0, 3).map((skill, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
                {candidate.skills && candidate.skills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{candidate.skills.length - 3}
                  </Badge>
                )}
              </div>

              {/* Details */}
              <div className="mt-4 space-y-1 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  <span>{candidate.experience_years} years experience</span>
                </div>
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4" />
                  <span>{candidate.education || 'Not specified'}</span>
                </div>
                {candidate.area && (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{candidate.area}</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="mt-4 flex gap-2">
                <Button asChild variant="outline" className="flex-1">
                  <Link href={`/company/candidates/${candidate.id}`}>View Profile</Link>
                </Button>
                <Button asChild className="flex-1 bg-[#e87e0d] hover:bg-[#d16f0a]">
                  <Link href={`/company/interviews/request?candidate=${candidate.id}`}>
                    Request Interview
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCandidates.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No candidates found matching your criteria</p>
            <Button variant="outline" onClick={clearAllFilters}>
              Clear All Filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
