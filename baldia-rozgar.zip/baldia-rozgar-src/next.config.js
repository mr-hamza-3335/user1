/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  distDir: '/tmp/dist',
  images: {
    unoptimized: true,
  },
}

module.exports = nextConfig
