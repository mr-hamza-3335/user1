# Baldia Rozgar - Employment Platform

A centralized employment platform for industries in Baldia Town, Karachi.

## Overview

Baldia Rozgar connects job seekers with companies in Baldia Town. All candidate profiles and CVs are uploaded by Admin or HR users, and companies can browse, search, filter, shortlist, and send interview requests to pre-verified candidates.

## Tech Stack

- **Frontend**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Backend**: Next.js API Routes
- **Database**: Supabase (PostgreSQL)
- **Auth**: Supabase Auth
- **Storage**: Supabase Storage (CV files)

## User Roles

### 1. Admin
- Approve or reject company registrations
- Add, edit, delete candidates
- Upload and manage CVs
- Create HR user accounts
- View all platform activity and stats

### 2. HR
- Add new candidates with full profile
- Upload CVs for candidates
- Edit candidate information
- Cannot approve companies or see company data

### 3. Company
- Self-registers via public signup page
- Must be approved by Admin before login access
- Search and filter candidates
- View candidate profiles and CVs
- Shortlist candidates
- Send interview requests
- Update hiring status

## Environment Variables

Create a `.env.local` file with:

```env
NEXT_PUBLIC_SUPABASE_URL=https://iymdlqoxgmsmsyqjrzii.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_TgG_SCPS28l8eh7h0My4PA_vgYuBYcP
SUPABASE_SERVICE_ROLE_KEY=sb_secret_QqPccLPXxQKwsDAjPLdeLg_xKGJb4ka
```

## Database Setup

Run the SQL schema in Supabase SQL Editor to create all tables:

1. `profiles` - User profiles
2. `companies` - Company registrations
3. `candidates` - Candidate profiles
4. `candidate_cvs` - CV file records
5. `shortlists` - Company shortlists
6. `interview_requests` - Interview requests
7. `hiring_records` - Hiring records
8. `activity_logs` - Activity logs

## Installation

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deployment

Deploy to Vercel:

1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

## Features

- Role-based authentication
- Company registration with admin approval
- Candidate management (CRUD)
- CV upload (PDF, DOC, DOCX)
- Advanced candidate search with filters
- Shortlist management
- Interview request system
- Hiring tracking
- Activity logging

## License

MIT
